<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <link rel="stylesheet" href="css/bootstrap.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link href="https://fonts.googleapis.com/css?family=Cabin+Sketch|Chathura|Codystar|Cormorant+Garamond|Courgette|Faster+One|Hanalei|Lobster|Monoton|Nosifer|Oswald|Rokkitt|Shadows+Into+Light|Tangerine|Wire+One|Yrsa" rel="stylesheet">
    <link rel="icon" href="images/rmlogo.png">
    <title>comming soon</title>
</head>
<body>
        <div class="panel panel-danger">
                <div class="panel-heading text-center">!!!!!!!!!!!</div>
                <div class="panel-body text-center">
                  <p class="" style="font-size:40px; color:rgb(209, 47, 47);">Comming Soon...</p>
                  <a href="index.php" class="btn btn-danger">Go to Back</a>
                </div>
        </div>
</body>
</html>