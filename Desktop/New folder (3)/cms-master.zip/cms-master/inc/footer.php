<div class="well well-sm footer">
    <p class="text-center">&copy; copyright 2018 <a href="https://www.getrmsoft.com">RMsoft.com</a></p>
</div>

    
      <!-- Optional JavaScript -->
    
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="js/jquery.min.js"></script>
    <script src="js/bootstrap.js"></script>
  </body>
</html>